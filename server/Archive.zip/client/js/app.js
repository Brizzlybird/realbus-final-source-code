app = angular.module('realbus', [
  'ngAnimate'
]);
// console.log('hello!');

app.controller('BusCtrl', function($scope, $http){
  $scope.hello = 'World';

  console.log('initializing');

// bus-bus id and then ng-repeat

    $scope.bus_stop = [
      'cheddar-grove-0100BRA10081',
      'bishopsworth-0100BRA10086',
      'bishport-0100BRA10108',
      'hengrove-0100FBX18342',
    ];

  // $scope.busData = {};
  // $scope.busData.doClick = function(item, event){

    var url = "js/test_data.json";

    var responsePromise = $http.get(url)
    .then(function(response){
      $scope.content = response.data;
      console.log(response.data);
      $scope.statuscode = response.status;
      $scope.statustext = response.statustext;

      var time1;

      $scope.createTimeArray = function() {
        // var vehicle = $scope.content.data.rtiReports[0].upcomingCalls[0].vehicleRTI.vehicleID;

        if($scope.content.bus[0].stopId == '123'){
          var time1 = $scope.content.bus[0].expectedDepartureTime;
          var datetime = new Date(time1);
          var hours = datetime.getHours();
          var minutes = datetime.getMinutes();
          var seconds = datetime.getSeconds();
          var time2 = hours + ':' + minutes + ':' + seconds;
        }
          console.log(time2);

          if($scope.content.bus[1].stopId == '234'){
          var time3 = $scope.content.bus[1].expectedArrivalTime;
          var datetime = new Date(time3);
          var hours = datetime.getHours();
          var minutes = datetime.getMinutes();
          var seconds = datetime.getSeconds();
          var time4 = hours + ':' + minutes + ':' + seconds;
        }

          function parseTime(s) {
             var c = s.split(':');
             return parseInt(c[0]) * 60 + parseInt(c[1]);
          }

          var nextStop = parseTime(time4) - parseTime(time2);

          var minutesToStop = nextStop * 60;

          // for the sake of making this working now, I'm going to hard code some remaining seconds.
          var remaining = 200;

          $scope.percentage = (remaining/minutesToStop) * 100;

      }

      $scope.createTimeArray();
    });

// Animate the bus along the path using the estimated
// percentage through its journey. This is all
// estimations

    $scope.isMoving = false;
    $scope.moveIt = function(){
      $scope.isMoving = true;

        document.getElementById('bus-icon').animate([
             { offsetDistance: $scope.percentage + '%' },
             { offsetDistance: '100%' }
        ], 30000);
    }

  // }

});

// $scope.distanceData = [];
// $scope.createDistanceArray = function(){
//   for(var i = 0; i < $scope.content.bus.length; i++){
//     $scope.distanceData.push({'id': $scope.content.bus[i].vehicleID,
//     'stopDis': $scope.content.bus[i].nextStopDistance, 'metDis': $scope.content.bus[i].metersDistance});
//     // $scope.distanceData.push('stopDis': $scope.content.bus[i].nextStopDistance);
//     // $scope.distanceData.push('metDis': $scope.content.bus[i].metersDistance);
//   }
// }
//
// $scope.createDistanceArray();
//
// $scope.percentageArray = [];
// // $scope.travelPercentage = [];
// $scope.percentageDone = function(){
//   // for(var i = 0; i < $scope.distanceData; i++){
//     $scope.percentage = 100 - (($scope.content.bus[0].metersDistance / $scope.content.bus[0].nextStopDistance) * 100);
//     // $scope.travelPercentage.push({'id': $scope.distanceData[i]['id'], 'percent': $scope.percentage[i]});
//     // $scope.percentageArray.push($scope.percentage[i]);
//   // }
// }
//
// $scope.percentageDone();
//
// // console.log($scope.percentageArray);
//
// console.log($scope.percentage + '%');


// Create directive to control the adding of
// a class that will move the bus along the path
// app.directive("moveBus", function($animate){
//   return function(scope, element, attrs){
//     scope.$watch(attrs.moveBus, function(newVal){
//       console.log('newVal', newVal);
//       if(newVal == true) {
//         console.log('yep!');
//         $animate.addClass(element, "move");
//       }
//     });
//   }
// });


// Create the animation that will more the bus
// along the path.
// This should all, essentially, be the same as
// the way I had done it previously.
// app.animation(".move", function(){
//   console.log('in directive');
//   return{
//     addClass: function(element, className){
//       element.animate([
//           { offsetDistance: 0 },
//           { offsetDistance: '100%' }
//         ], 30000);
//     }
//   }
// });




// busIcon.animate([
//     { offsetDistance: 0 },
//     { offsetDistance: '100%' }
//   ], 30000);

  // var time = 100 - ((timeRemaining / timeTotal) * 100);

  /*
    It takes 11 minutes to travel between each of the main bus stops I've outlined in the data.
    There's a distance of 1.8 miles between Bishopsworth library and Bishport and 1.7 miles between Bishport and
    Hengrove depot. I need to use the estimated departure time and estimate arrival time to find the percentage.
  */
