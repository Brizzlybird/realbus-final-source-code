/**
 * Realbus - description
 * @author clare marsh
 */

"use strict";

var Components = {
  Webserver: require('./server/webserver'),
  DataConnector: require('./server/dataconnector')
};

class RealbusServer {

  /**
   * Constructor
   */
  constructor() {

    this.cache         = {};
    this.webserver     = new Components.Webserver();
    this.dataconnector = new Components.DataConnector();

  }

  /**
   * Initialize the application
   */
  start() {

    var server = this;

    this.webserver.start();

    this.dataconnector.getData().then(

      results => {
        for (let result of results) {
          try {
            result = JSON.parse(result);
          } catch (e) {
            console.error('There was a problem parsing the JSON data:');
            console.error(e.message);
            continue;
          }

          var stopID = result.data.stopID;
          server.cache[stopID] = {};

          let report = result.data.rtiReports[0];
          try {
            if ('upcomingCalls' in report) {
              console.log('found upcoming calls');
              let vehicleRTI = report.upcomingCalls[0].vehicleRTI;
              if ('vehicleID' in vehicleRTI) {
                let vehicleID = vehicleRTI.vehicleID;
                server.cache[vehicleID] = {};
              }
            }
          } catch (e) {
            console.error(e);
          }

          //if ('vehicleID' in result.vehicleRTI)
          //   this.cache[stopID].vehicleID = result.vehicleRTI.vehicleID;

        }
        console.log(this.cache);
      },

      error => {
        console.log('There was an error');
      }

    );

  }


}

global.app = new RealbusServer();
app.start();
